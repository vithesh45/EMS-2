from django.contrib import admin
from .models import (
    Material, Supplier, SubContractor, Inward, InwardItem,
    Outward, OutwardItem, Stock, SubContractorStock
)

@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ('material_name', 'unit')
    search_fields = ('material_name',)

@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ('supplier_name', 'supplier_address')
    search_fields = ('supplier_name',)

@admin.register(SubContractor)
class SubContractorAdmin(admin.ModelAdmin):
    list_display = ('sub_contractor_name', 'division', 'sub_contractor_licence_no')
    search_fields = ('sub_contractor_name', 'division')

class InwardItemInline(admin.TabularInline):
    model = InwardItem
    extra = 1

@admin.register(Inward)
class InwardAdmin(admin.ModelAdmin):
    list_display = ('invoice_nmbr', 'supplier', 'date', 'vehicle_nmbr')
    inlines = [InwardItemInline]
    search_fields = ('invoice_nmbr', 'supplier__supplier_name')

class OutwardItemInline(admin.TabularInline):
    model = OutwardItem
    extra = 1

@admin.register(Outward)
class OutwardAdmin(admin.ModelAdmin):
    list_display = ('indent_no', 'sub_contractor', 'date', 'vehicle_no')
    inlines = [OutwardItemInline]
    search_fields = ('indent_no', 'sub_contractor__sub_contractor_name')

@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ('material_name', 'quantity', 'last_updated')

    @admin.display(description='Material')
    def material_name(self, obj):
        return obj.material.material_name

@admin.register(SubContractorStock)
class SubContractorStockAdmin(admin.ModelAdmin):
    list_display = ('material_name', 'sub_contractor_name', 'quantity')

    @admin.display(description='Material')
    def material_name(self, obj):
        return obj.material.material_name

    @admin.display(description='Sub Contractor')
    def sub_contractor_name(self, obj):
        return obj.sub_contractor.sub_contractor_name