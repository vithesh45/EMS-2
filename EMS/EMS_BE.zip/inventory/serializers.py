from rest_framework import serializers
from .models import (
    Material, Supplier, SubContractor, Inward, InwardItem,
    Outward, OutwardItem, Stock, SubContractorStock
)

class MaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Material
        fields = '__all__'

class SupplierSerializer(serializers.ModelSerializer):
    class Meta:
        model = Supplier
        fields = '__all__'

class SubContractorSerializer(serializers.ModelSerializer):
    class Meta:
        model = SubContractor
        fields = '__all__'

class InwardItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = InwardItem
        fields = '__all__'

class InwardSerializer(serializers.ModelSerializer):
    items = InwardItemSerializer(many=True)

    class Meta:
        model = Inward
        fields = '__all__'

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        inward = Inward.objects.create(**validated_data)
        for item_data in items_data:
            InwardItem.objects.create(inward=inward, **item_data)
        return inward

class OutwardItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OutwardItem
        fields = '__all__'

class OutwardSerializer(serializers.ModelSerializer):
    items = OutwardItemSerializer(many=True)

    class Meta:
        model = Outward
        fields = '__all__'

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        outward = Outward.objects.create(**validated_data)
        for item_data in items_data:
            OutwardItem.objects.create(outward=outward, **item_data)
        return outward

class StockSerializer(serializers.ModelSerializer):
    material_name = serializers.CharField(source='material.material_name', read_only=True)
    unit = serializers.CharField(source='material.unit', read_only=True)

    class Meta:
        model = Stock
        fields = ['material', 'material_name', 'unit', 'quantity', 'last_updated']