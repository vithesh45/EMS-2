# Create your models here.
from django.db import models
import uuid

class Material(models.Model):
    material_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    material_name = models.CharField(max_length=100)
    unit = models.CharField(max_length=20)
    description = models.TextField(blank=True)
    def __str__(self):
        return self.material_name

class Supplier(models.Model):
    supplier_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    supplier_name = models.CharField(max_length=100)
    supplier_address = models.TextField()
    def __str__(self):
        return self.supplier_name

class SubContractor(models.Model):
    sub_contractor_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    sub_contractor_name = models.CharField(max_length=100)
    sub_contractor_licence_no = models.CharField(max_length=50)
    division = models.CharField(max_length=50)
    def __str__(self):
        return self.sub_contractor_name

class SubContractorStock(models.Model):
    sub_contractor = models.ForeignKey(SubContractor, on_delete=models.CASCADE)
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=0)
   
class Stock(models.Model):
    material = models.OneToOneField(Material, on_delete=models.CASCADE, primary_key=True)
    quantity = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    last_updated = models.DateTimeField(auto_now=True)
    def __str__(self):
        return f"{self.material.material_name} - {self.quantity}"

class Inward(models.Model):
    inward_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE)
    invoice_nmbr = models.CharField(max_length=100)
    date = models.DateField()
    dc_no = models.CharField(max_length=100)
    lr_no = models.CharField(max_length=100)
    vehicle_nmbr = models.CharField(max_length=50)
    received_by = models.CharField(max_length=100)
    remarks = models.TextField(blank=True)
    def __str__(self):
        return f"Inward {self.invoice_nmbr}"

class InwardItem(models.Model):
    inward = models.ForeignKey(Inward, on_delete=models.CASCADE, related_name='items')
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    as_per_challan = models.DecimalField(max_digits=10, decimal_places=2)
    actual = models.DecimalField(max_digits=10, decimal_places=2)
    rejected = models.DecimalField(max_digits=10, decimal_places=2)
    accepted = models.DecimalField(max_digits=10, decimal_places=2)
    remarks = models.TextField(blank=True)

class Outward(models.Model):
    outward_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    sub_contractor = models.ForeignKey(SubContractor, on_delete=models.CASCADE)
    indent_no = models.CharField(max_length=100)
    date = models.DateField()
    vehicle_no = models.CharField(max_length=50)
    issued_by = models.CharField(max_length=100)
    remarks = models.TextField(blank=True)
    def __str__(self):
        return f"Outward {self.indent_no}"

class OutwardItem(models.Model):
    outward = models.ForeignKey(Outward, on_delete=models.CASCADE, related_name='items')
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)