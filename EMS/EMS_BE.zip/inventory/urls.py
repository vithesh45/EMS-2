from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import *

router = DefaultRouter()
router.register('materials', MaterialViewSet)
router.register('suppliers', SupplierViewSet)
router.register('subcontractors', SubContractorViewSet)
router.register('inward', InwardViewSet)
router.register('outward', OutwardViewSet)
router.register('stock', StockViewSet)

urlpatterns = [
    path('', include(router.urls))
]

